// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.market;

public class MarketIndicesRequest
{
    protected String indexSymbol;
    
    public String getIndexSymbol() {
        return this.indexSymbol;
    }
    
    public void setIndexSymbol(final String value) {
        this.indexSymbol = value;
    }
}
