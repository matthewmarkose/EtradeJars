// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.market;

public enum DetailFlag
{
    ALL, 
    FUNDAMENTAL, 
    INTRADAY, 
    OPTIONS, 
    WEEK_52;
}
