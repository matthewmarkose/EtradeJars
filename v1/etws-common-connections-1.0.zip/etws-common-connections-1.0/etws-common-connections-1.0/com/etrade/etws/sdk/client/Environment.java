// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.sdk.client;

public enum Environment
{
    SANDBOX, 
    LIVE;
}
