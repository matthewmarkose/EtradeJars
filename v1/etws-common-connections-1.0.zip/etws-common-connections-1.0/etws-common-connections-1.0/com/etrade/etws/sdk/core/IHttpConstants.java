// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.sdk.core;

public interface IHttpConstants
{
    public static final String GET = "GET";
    public static final String POST = "POST";
    public static final String DELETE = "DELETE";
    public static final String PUT = "PUT";
}
