// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.account;

public class AccountStatus
{
    protected String accountId;
    protected String errorMessage;
    
    public String getAccountId() {
        return this.accountId;
    }
    
    public String getErrorMessage() {
        return this.errorMessage;
    }
}
