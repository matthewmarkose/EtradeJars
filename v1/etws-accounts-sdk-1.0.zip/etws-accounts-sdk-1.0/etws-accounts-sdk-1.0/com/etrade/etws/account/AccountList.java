// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.account;

public class AccountList
{
}
