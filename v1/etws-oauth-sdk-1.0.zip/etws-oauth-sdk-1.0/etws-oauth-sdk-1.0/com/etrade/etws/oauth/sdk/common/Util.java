// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.oauth.sdk.common;

import java.util.Properties;

public class Util
{
    public static Properties props;
    
    static {
        Util.props = new Properties();
    }
}
