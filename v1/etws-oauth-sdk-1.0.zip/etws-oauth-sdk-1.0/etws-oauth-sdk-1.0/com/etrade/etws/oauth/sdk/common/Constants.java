// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.oauth.sdk.common;

public interface Constants
{
    public static final String LOG4J_PROPERITES = "log4j.properties";
    public static final String CALLBACK_METHOD = "oob";
    public static final String GET_REQUEST_TOKEN = "request_token";
    public static final String GET_ACCESS_TOKEN = "access_token";
    public static final String RENEW_TOKEN = "renew_access_token";
    public static final String REVOKE_TOKEN = "revoke_access_token";
}
