// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class PlaceEquityOrder
{
    protected EquityOrderRequest equityOrderRequest;
    
    public EquityOrderRequest getEquityOrderRequest() {
        return this.equityOrderRequest;
    }
    
    public void setEquityOrderRequest(final EquityOrderRequest value) {
        this.equityOrderRequest = value;
    }
}
