// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class CancelOrderResponse
{
    protected CancelResponse cancelResponse;
    
    public CancelResponse getCancelResponse() {
        return this.cancelResponse;
    }
}
