// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class PlaceChangeOptionOrderResponse
{
    protected ChangeOptionOrderResponse optionOrderResponse;
    
    public ChangeOptionOrderResponse getOptionOrderResponse() {
        return this.optionOrderResponse;
    }
}
