// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class ETAppMessages
{
    protected String msgDesc;
    protected int msgCode;
    
    public String getMsgDesc() {
        return this.msgDesc;
    }
    
    public void setMsgDesc(final String value) {
        this.msgDesc = value;
    }
    
    public int getMsgCode() {
        return this.msgCode;
    }
    
    public void setMsgCode(final int value) {
        this.msgCode = value;
    }
}
