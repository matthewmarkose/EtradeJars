// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class GetOrderListResponse
{
    protected OrderListResponse orderListResponse;
    
    public OrderListResponse getOrderListResponse() {
        return this.orderListResponse;
    }
}
