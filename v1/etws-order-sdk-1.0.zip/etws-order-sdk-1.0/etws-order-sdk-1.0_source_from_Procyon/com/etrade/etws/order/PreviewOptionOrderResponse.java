// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class PreviewOptionOrderResponse
{
    protected OptionOrderResponse optionOrderResponse;
    
    public OptionOrderResponse getOptionOrderResponse() {
        return this.optionOrderResponse;
    }
}
