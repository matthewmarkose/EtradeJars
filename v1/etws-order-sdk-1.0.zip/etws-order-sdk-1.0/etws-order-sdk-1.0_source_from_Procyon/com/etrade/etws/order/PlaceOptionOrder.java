// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class PlaceOptionOrder
{
    protected OptionOrderRequest optionOrderRequest;
    
    public OptionOrderRequest getOptionOrderRequest() {
        return this.optionOrderRequest;
    }
    
    public void setOptionOrderRequest(final OptionOrderRequest value) {
        this.optionOrderRequest = value;
    }
}
