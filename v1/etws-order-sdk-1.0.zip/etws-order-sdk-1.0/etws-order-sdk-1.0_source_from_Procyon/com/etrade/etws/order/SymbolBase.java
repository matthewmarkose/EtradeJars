// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class SymbolBase
{
    protected String symbol;
    protected OrderType type;
    
    public String getSymbol() {
        return this.symbol;
    }
    
    public OrderType getType() {
        return this.type;
    }
}
