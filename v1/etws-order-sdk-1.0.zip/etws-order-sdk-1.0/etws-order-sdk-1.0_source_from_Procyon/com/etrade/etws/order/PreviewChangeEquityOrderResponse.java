// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class PreviewChangeEquityOrderResponse
{
    protected ChangeEquityOrderResponse equityOrderResponse;
    
    public ChangeEquityOrderResponse getEquityOrderResponse() {
        return this.equityOrderResponse;
    }
}
