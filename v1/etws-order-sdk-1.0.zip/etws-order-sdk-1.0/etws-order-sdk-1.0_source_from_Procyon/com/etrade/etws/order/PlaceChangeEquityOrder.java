// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class PlaceChangeEquityOrder
{
    protected ChangeEquityOrderRequest changeEquityOrderRequest;
    
    public ChangeEquityOrderRequest getChangeEquityOrderRequest() {
        return this.changeEquityOrderRequest;
    }
    
    public void setChangeEquityOrderRequest(final ChangeEquityOrderRequest value) {
        this.changeEquityOrderRequest = value;
    }
}
