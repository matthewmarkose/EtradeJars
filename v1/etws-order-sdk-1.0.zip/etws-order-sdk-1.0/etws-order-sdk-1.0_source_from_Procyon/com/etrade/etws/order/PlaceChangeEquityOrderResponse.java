// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class PlaceChangeEquityOrderResponse
{
    protected ChangeEquityOrderResponse equityOrderResponse;
    
    public ChangeEquityOrderResponse getEquityOrderResponse() {
        return this.equityOrderResponse;
    }
}
