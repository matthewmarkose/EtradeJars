// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class OrderDetails
{
    protected GroupOrder groupOrder;
    protected Order order;
    
    public GroupOrder getGroupOrder() {
        return this.groupOrder;
    }
    
    public Order getOrder() {
        return this.order;
    }
}
