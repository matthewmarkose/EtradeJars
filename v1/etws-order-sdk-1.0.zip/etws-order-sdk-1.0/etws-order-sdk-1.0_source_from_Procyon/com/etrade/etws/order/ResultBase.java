// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class ResultBase
{
    protected String accountId;
    
    public String getAccountId() {
        return this.accountId;
    }
}
