// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class CancelOrder
{
    protected CancelOrderRequest cancelOrderRequest;
    
    public CancelOrderRequest getCancelOrderRequest() {
        return this.cancelOrderRequest;
    }
    
    public void setCancelOrderRequest(final CancelOrderRequest value) {
        this.cancelOrderRequest = value;
    }
}
