// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class PlaceEquityOrderResponse
{
    protected EquityOrderResponse equityOrderResponse;
    
    public EquityOrderResponse getEquityOrderResponse() {
        return this.equityOrderResponse;
    }
}
