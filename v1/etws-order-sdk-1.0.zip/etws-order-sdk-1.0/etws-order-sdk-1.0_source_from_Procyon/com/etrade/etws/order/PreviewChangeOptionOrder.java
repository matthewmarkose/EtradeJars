// 
// Decompiled by Procyon v0.5.36
// 

package com.etrade.etws.order;

public class PreviewChangeOptionOrder
{
    protected ChangeOptionOrderRequest changeOptionOrderRequest;
    
    public ChangeOptionOrderRequest getChangeOptionOrderRequest() {
        return this.changeOptionOrderRequest;
    }
    
    public void setChangeOptionOrderRequest(final ChangeOptionOrderRequest value) {
        this.changeOptionOrderRequest = value;
    }
}
